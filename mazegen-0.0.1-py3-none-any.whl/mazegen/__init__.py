"""Maze generator package."""

from .generator import MazeGenerator as MazeGenerator

__all__ = ["MazeGenerator"]
